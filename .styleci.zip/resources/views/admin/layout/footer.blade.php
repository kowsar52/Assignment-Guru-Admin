<div class="xp-footerbar">
                <footer class="footer">
                    <p class="mb-0">© 2020 Numberish - All Rights Reserved.</p>
                </footer>
            </div>
            <!-- End XP Footerbar -->

        </div>
        <!-- End XP Rightbar -->

    </div>
    <!-- End XP Container -->

    <!-- Start JS -->        
    
    <script src="{{asset('/')}}assets/js/popper.min.js"></script>
    <script src="{{asset('/')}}assets/js/bootstrap.min.js"></script>
    <script src="{{asset('/')}}assets/js/modernizr.min.js"></script>
    <script src="{{asset('/')}}assets/js/detect.js"></script>
    <script src="{{asset('/')}}assets/js/jquery.slimscroll.js"></script>
    <script src="{{asset('/')}}assets/js/sidebar-menu.js"></script>

    <!-- Chartist Chart JS -->
    {{-- <script src="{{asset('/')}}assets/plugins/chartist-js/chartist.min.js"></script>
    <script src="{{asset('/')}}assets/plugins/chartist-js/chartist-plugin-tooltip.min.js"></script> --}}

    <!-- To Do List JS -->
    <script src="{{asset('/')}}assets/js/init/to-do-list-init.js"></script>

    <!-- Datepicker JS -->
    <script src="{{asset('/')}}assets/plugins/datepicker/datepicker.min.js"></script>
    <script src="{{asset('/')}}assets/plugins/datepicker/i18n/datepicker.en.js"></script>

    <!-- Dashboard JS -->
    <script src="{{asset('/')}}assets/js/init/dashborad.js"></script>
 

    <!-- Main JS -->
    <script src="{{asset('/')}}assets/js/main.js"></script>
    <script src="{{asset('/')}}assets/js/dataTables.min.js"></script>
    <!-- End JS -->
    <script src="https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>


</body>
</html>