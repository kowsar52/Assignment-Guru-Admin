<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | File paths
    |--------------------------------------------------------------------------
    */

    // Users Avatar and Cover Path
    'avatar' => 'uploads/avatar/',

    // Images, Video and Audio Path
    'messages' => 'uploads/messages/',

    // Verification User
    'verification' => 'uploads/verification/',

    // Admin (Pages and Blog Post)
    'admin' => 'uploads/admin/',
);
