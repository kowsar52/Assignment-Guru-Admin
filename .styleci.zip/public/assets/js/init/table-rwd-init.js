"use strict";
$(document).ready(function() {    

    /* -----  Table - RWD ----- */
    $('.xp-rwd-table').responsiveTable('update');

});