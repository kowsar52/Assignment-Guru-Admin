"use strict";
$(document).ready(function() {    

    /* -----  Email ----- */
    $('.summernote').summernote({
        height: 200,
        minHeight: null,
        maxHeight: null,
        focus: true 
    });

});